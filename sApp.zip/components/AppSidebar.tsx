"use client";

import Link from "next/link";

export default function AppSidebar() {
	return (
		<aside className="rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
			<h3 className="mb-2 text-sm font-semibold text-stone-800">Quick Links</h3>
			<ul className="space-y-2 text-sm">
				<li>
					<Link
						className="text-stone-700 hover:underline"
						href="/events/hilf-al-fudul"
					>
						Hilf al-Fudul
					</Link>
				</li>
				<li>
					<Link className="pointer-events-none text-stone-400" href="#">
						Event 2 (coming soon)
					</Link>
				</li>
			</ul>

			{/* TODO(back-end): Replace static links with a DB-driven event list:
         - fetch('/api/events') and map results to links
         - cache with SWR/React Query
      */}
		</aside>
	);
}
