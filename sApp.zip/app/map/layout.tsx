import 'maplibre-gl/dist/maplibre-gl.css';

export default function MapLayout({ children }: { children: React.ReactNode }) {
  return <section>{children}</section>;
}
