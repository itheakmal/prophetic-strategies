export default function Nabuwah() {
  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-6 text-stone-700 shadow-sm">
      <h1 className="text-xl font-semibold text-stone-900">Event 2</h1>
      <p className="mt-2 text-sm">Content is coming soon.</p>
    </div>
  );
}
