import AppSidebar from '@/components/AppSidebar';

export default function EventsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid gap-5 md:grid-cols-[260px_1fr]">
      <AppSidebar />
      <div>{children}</div>
    </div>
  );
}
